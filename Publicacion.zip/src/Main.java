//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
void main() {
    Scanner sc = new Scanner(System.in);

    System.out.println("Diga un libro o revista: ");
    String libroOrevista = sc.nextLine().toLowerCase();
    System.out.println("¿Quíen es su autor?");
    String autor = sc.nextLine().toUpperCase();
    System.out.println("¿Cuántas páginas tiene?");
    int numeroPaginas = sc.nextInt();
    System.out.println("¿Número de ediciones?");
    int numeroEdiciones = sc.nextInt();

    libro lb = new libro(libroOrevista, autor, numeroPaginas,numeroEdiciones);
    revista rv = new revista(libroOrevista, autor, numeroPaginas,numeroEdiciones);

    if (libroOrevista.equals("libro")) {
        System.out.println("Datos introducidos: " + lb.conjunto());
    } else if (libroOrevista.equals("revista")) {
        System.out.println("Datos introducidos: " +rv.conjunto());
    }
    else {
        System.out.println("Error");
    }


}
