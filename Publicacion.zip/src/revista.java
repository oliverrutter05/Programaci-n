public class revista extends publicacion{

    public int numeroPaginas;
    public int numeroEdiciones;

    public revista(String libro, String autor, int numeroPaginas, int numeroEdiciones) {
        super(libro, autor);
        this.numeroEdiciones = numeroEdiciones;
        this.numeroPaginas = numeroPaginas;
    }

    public String conjunto() {
        System.out.println(numeroPaginas + numeroEdiciones);
        return "";
    }
}
