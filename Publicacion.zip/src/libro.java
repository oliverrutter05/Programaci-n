public class libro extends publicacion{

    public int numeroPaginas;
    public int numeroEdiciones;

    public libro(String libro, String autor, int numeroEdiciones, int numeroPaginas) {
        super(libro, autor);
        this.numeroEdiciones = numeroEdiciones;
        this.numeroPaginas = numeroPaginas;
    }

    public String conjunto() {
        System.out.println(libro);
        return "";
    }
}
