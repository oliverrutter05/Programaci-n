public class publicacion {

    protected String libro;
    protected String autor;

    public publicacion(String libro, String autor) {
        this.libro = libro;
        this.autor = autor;
    }


}

