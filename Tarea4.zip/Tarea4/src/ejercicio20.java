public class ejercicio20 {
    static void main() {
        for (int i=1; i<=100; i++){
            if (i % 5 == 0){
                System.out.println("5 * " + (i/5) + " es igual a: " + i);
            }
        }
    }
}
